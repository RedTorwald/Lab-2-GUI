﻿using Microsoft.VisualBasic.Logging;

namespace FormFor
{
    public partial class Form1 : Form
    {
        int a;
        int b;
        public Form1()
        {
        InitializeComponent();
            textBox1.Text = Properties.Settings.Default.A.ToString();
            textBox2.Text = Properties.Settings.Default.B.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.A=a;
            Properties.Settings.Default.B=b;
            Properties.Settings.Default.Save();
            try
            {
                a=int.Parse(this.textBox1.Text);
                b=int.Parse(this.textBox2.Text);
            }
            catch(FormatException)
            {
                label4.Text="Error. Uncorrect input./Please, try again.";
                return; 
            }

            int counterA = 0;
            int counterB = 0;
            

            List<int> nums=new List<int>();
            string outMessage= "1) квадраты со сторонами: " +'\n';

            if (a==b){ outMessage="Введён квадрат";}
            while (a!=b)
            {
                if (a<b)
                {
                    b-=a;
                    counterA++;
                    outMessage+="|"+ a+"*"+ a+"|";    
                    outMessage+="  ";
                }
                else if (a>b)
                {
                    a-=b;
                    counterB++;
                    outMessage+="|"+b+"*"+b+"|";
                    //outMessage+='\n';
                    outMessage+="  ";
                }
                           
            }
            outMessage+="|"+a+"*"+ a+"|";
            outMessage+='\n';
            outMessage+="2) количество квадратов: "+Convert.ToString(counterA+counterB+1);

            label4.Text=outMessage;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            label6.Text="Дан прямоугольник с размерами a×b. От него отрезают квадраты максимального размера, пока это возможно. Затем от оставшегося прямоугольника вновь отрезают квадраты максимально возможного размера и т. д. На какие квадраты и в каком их количестве будет разрезан исходный прямоугольник?";
        }

       
    }
}