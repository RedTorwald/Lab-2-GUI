﻿namespace Form1f
{
    public partial class Form1 : Form
    {
        int n;
        
        public Form1()
        {
        InitializeComponent();
            textBox1.Text = Properties.Settings.Default.X.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.X=n;
            Properties.Settings.Default.Save();
            
            try
            {
                n=int.Parse(this.textBox1.Text);
            }
            catch(FormatException)
            {
                label4.Text="Ошибка. Введенно неверное значение.";
                return; 
            }

            int a=0;
            int b=0;
            string msg="";
            string msg1 = "";
           
            string outMessage= "";
            
            if ((n > 1) && (n < 9999))
            {
                a = n / 100;

                if (a % 100 >= 11 && a % 100 <= 19 ) { msg = "рублей"; }
                else if (a % 10 == 1){msg = "рубль";}
                else if (a%10 >= 2  && a%10 <= 4) { msg = "рубля"; }
                else { msg = "рублей"; }

                b = n % 100; 
                if (b % 100 >= 11 && b % 100 <= 19 ) { msg1 = "копеек"; }
                else if (b % 10 == 1){msg1 = "копейка";}
                else if (b%10 >= 2  && b%10 <= 4) { msg1 = "копейки"; }
                else { msg1 = "копеек"; }
                outMessage=a+" "+msg+" "+b+" "+msg1;
            }
            else
            {
                outMessage="введённое значение не находится в промежутке (1, 9999)";
            }
                     
            label4.Text=outMessage;
        }

        private void button2_Click(object sender, EventArgs e)
        {
             label6.Text="Дано натуральное число 1≤n≤9999, определяющее стоимость товара в копейках. Выразить стоимость в рублях и копейках, например, 3 рубля 21 копейка, 15 рублей 5 копеек, 1 рубль ровно и т. п.\r\n\r\n";
        }

    }
}